if (document.querySelector('.we-offer')) {
  const accordion1 = new GraphAccordion('.accordion-1', {
    speed: 300
  });

  const accordion2 = new GraphAccordion('.accordion-2', {
    speed: 300
  });
}

