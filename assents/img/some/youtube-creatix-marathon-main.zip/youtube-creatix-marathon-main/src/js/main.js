/**
  * название функции
  *
  * @param {number} first - первое число
  * @returns {number}
  */
